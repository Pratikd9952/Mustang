package _POM_Package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base_Package.Base_Class;

public class Hidden_Loginpopup extends Base_Class {

	@FindBy(xpath = "//button[text()='✕']")
	private WebElement Cross;

	@FindBy(xpath = "//a[text()='Login']")
	private WebElement LoginTab;
	
	Hidden_Loginpopup(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void Cross() {
		this.Cross.click();
	}

	public void LoginTab() {
		this.LoginTab.click();
	}
}
