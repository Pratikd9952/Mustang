package _POM_Package;

public class Card {

}
