package _POM_Package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base_Package.Base_Class;

public class Login extends Base_Class{

	@FindBy(xpath = "(//input[@autocomplete='off'])[2]")
	private WebElement MobileNo;

	@FindBy(xpath = "(//input[@autocomplete='off'])[3]")
	private WebElement Passward;

	@FindBy(xpath = "(//button[@type='submit'])[2]")
	private WebElement Submit;

	Login(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public String UserName(String MobileNo) {
		this.MobileNo.sendKeys(MobileNo);
		return MobileNo;
	}

	public String Passward(String Passward) {
		this.Passward.sendKeys(Passward);
		return Passward;
	}

	public void Submit() {
		this.Submit.click();
	}

}
