package _POM_Package;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base_Package.Base_Class;

public class Home_Page extends Base_Class{
	
	Actions action = new Actions(driver());
	JavascriptExecutor js = (JavascriptExecutor) driver;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement Searchbox;

	@FindBy(xpath = "(//div[@class='exehdJ'])[1]")
	private WebElement name;

	@FindBy(xpath = "//span[text()='Men']")
	private WebElement Mens;

	@FindBy(xpath = "//a[text()='Fastrack']")
	private WebElement Fastrack;

	@FindBy(xpath = "//div[text()='Discount']")
	private WebElement Scrolldown;

	@FindBy(xpath = "//a[text()='38024PP25 Minimalists Analog Watch  - For Men']")
	private WebElement Watch;

	Home_Page(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public String Searchbox(String ProductName) {
		Searchbox.sendKeys(ProductName, Keys.ENTER);
		return ProductName;
	}

	public void name() {
		action.moveToElement(name).perform();
	}

	public void Mens() throws InterruptedException {
		action.moveToElement(Mens).perform();
		Thread.sleep(3000);
	}

	public void Fastrack() {
		action.moveToElement(Fastrack).click().build().perform();
	}

	public void Scroll() {
		js.executeScript("arguments[0].scrollIntoView(true);", Scrolldown);
		js.executeScript("window.scrollBy(0,-600)");
	}

	public void Watch() {
		Watch.click();
	}
}
